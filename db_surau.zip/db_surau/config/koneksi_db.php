<?php
define('HOST','localhost');
define('USER','root');
define('DB','db_surau');
define('PASS','');

$con = new mysqli(HOST,USER,PASS,DB) or die('gagal koneksi ke database');

if($con){
    echo 'Connection Successful';
} else {
    echo 'gagal';
}
?>