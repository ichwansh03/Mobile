<?php 

header("Content-Type: application/json; charset=UTF-8");

require_once('../config/koneksi_db.php');

$key = $_POST['key'];

if ( $key == "update" ){

    $id         = $_POST['id'];
    $nama       = $_POST['nama'];
    $deskripsi  = $_POST['deskripsi'];
    $harga      = $_POST['harga'];
    $gambar    = $_POST['gambar'];
    
    $query = "UPDATE produk SET 
    nama='$nama', 
    deskripsi='$deskripsi', 
    gambar='$gambar',
    harga='$harga'
    WHERE id='$id' ";

        if ( mysqli_query($con, $query) ){

            if ($image == null) {

                $result["value"] = "1";
                $result["message"] = "Success";
    
                echo json_encode($result);
                mysqli_close($con);

            } else {

                $path = "product_images/$id.jpeg";
                $finalPath = "/db_surau/".$path;

                $insert_picture = "UPDATE produk SET image='$finalPath' WHERE id='$id' ";
            
                if (mysqli_query($con, $insert_picture)) {
            
                    if ( file_put_contents( $path, base64_decode($picture) ) ) {
                        
                        $result["value"] = "1";
                        $result["message"] = "Success!";
            
                        echo json_encode($result);
                        mysqli_close($con);
            
                    } else {
                        
                        $response["value"] = "0";
                        $response["message"] = "Error! ".mysqli_error($con);
                        echo json_encode($response);

                        mysqli_close($con);
                    }

                }
            }

        } 
        else {
            $response["value"] = "0";
            $response["message"] = "Error! ".mysqli_error($con);
            echo json_encode($response);

            mysqli_close($con);
        }
}

?>