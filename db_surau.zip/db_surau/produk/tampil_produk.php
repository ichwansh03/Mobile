<?php 

header("Content-Type: application/json; charset=UTF-8");

require_once('../config/koneksi_db.php');

$query = "SELECT * FROM produk ORDER BY id DESC ";
$result = mysqli_query($con, $query);
$response = array();

$server_name = $_SERVER['SERVER_ADDR'];

while( $row = mysqli_fetch_assoc($result) ){

    array_push($response, 
    array(
        'id'        =>$row['id'], 
        'nama'      =>$row['nama'], 
        'deskripsi' =>$row['deskripsi'],
        'harga'     =>$row['harga'],
        'gambar'    =>"http://$server_name" . $row['gambar']) 
    );
}

echo json_encode($response);

mysqli_close($con);

?>