<?php 

header("Content-Type: application/json; charset=UTF-8");

require_once('../config/koneksi_db.php');

$key = $_POST['key'];
$id      = $_POST['id'];
$gambar = $_POST['gambar'];

if ( $key == "delete" ){

    $query = "DELETE FROM produk WHERE id='$id' ";

        if ( mysqli_query($con, $query) ){

            $iparr = split ("/", $gambar);
            $picture_split = $iparr[5];

            if ( unlink("product_images/".$picture_split) ){

                $result["value"] = "1";
                $result["message"] = "Success!";

                echo json_encode($result);
                mysqli_close($con);

            } else {
            
                $response["value"] = "0";
                $response["message"] = "Error to delete a image! ".mysqli_error($con);
                echo json_encode($response);
    
                mysqli_close($con);
            }

        } 
        else {

            $response["value"] = "0";
            $response["message"] = "Error! ".mysqli_error($con);
            echo json_encode($response);

            mysqli_close($con);
        }

} else {
    $response["value"] = "0";
    $response["message"] = "Error! ".mysqli_error($con);
    echo json_encode($response);

    mysqli_close($con);
}

?>