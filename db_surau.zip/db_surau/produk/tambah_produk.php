<?php 

require_once('../config/koneksi_db.php');

$key = $_POST['key'];
$nama       = $_POST['nama'];
$deskripsi    = $_POST['deskripsi'];
$gambar      = $_POST['gambar'];
$harga     = $_POST['harga'];

if ( $key == "insert" ){

    $query = "INSERT INTO produk (nama,deskripsi,gambar,harga)
    VALUES ('$nama', '$deskripsi', '$gambar', '$harga') ";

        if ( mysqli_query($con, $query) ){

            if ($gambar == null) {

                $finalPath = "/db_surau/product_images/images.png"; 
                $result["value"] = "1";
                $result["message"] = "Success";
    
                echo json_encode($result);
                mysqli_close($con);

            } else {

                $id = mysqli_insert_id($con);
                $path = "../product_images/images.png";
                $finalPath = "/db_surau/".$path;

                $insert_picture = "UPDATE produk SET gambar='$finalPath' WHERE id='$id' ";
            
                if (mysqli_query($con, $insert_picture)) {
            
                    if ( file_put_contents( $path, base64_decode($gambar) ) ) {
                        
                        $result["value"] = "1";
                        $result["message"] = "Success!";
            
                        echo json_encode($result);
                        mysqli_close($con);
            
                    } else {
                        
                        $response["value"] = "0";
                        $response["message"] = "Error! ".mysqli_error($con);
                        echo json_encode($response);

                        mysqli_close($con);
                    }

                }
            }

        } 
        else {
            $response["value"] = "0";
            $response["message"] = "Error! ".mysqli_error($con);
            echo json_encode($response);

            mysqli_close($con);
        }
}

?>