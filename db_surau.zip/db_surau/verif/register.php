<?php
	require_once('../config/koneksi_db.php');

	$name = $_GET['name'];
	$address = $_GET['address'];
	$email = $_GET['email'];
	$phone = $_GET['phone'];
	$password = $_GET['password'];

	$queryRegister = "SELECT * FROM register WHERE email = '".$email."'";

	$msql = mysqli_query($conn, $queryRegister);

	$result = mysqli_num_rows($msql);

	if (!empty($name) && !empty($address) && !empty($email) && !empty($phone) && !empty($password)) {
		
		if ($result == 0) {
			
			$regis = "INSERT INTO register(name, address, email, phone, password) VALUES ('$name', '$address', '$email', '$phone', '$password')";
			$msqlRegis = mysqli_query($conn, $regis);

			echo "1";
		}else{
			echo "Email sudah di gunakan";
		}
	}else{
		echo "Semua data harus di isi lengkap";
	}
?>