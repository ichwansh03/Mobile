<?php 

header("Content-Type: application/json; charset=UTF-8");

require_once('../config/koneksi_db.php');

$query = "SELECT * FROM pemasukan ORDER BY id DESC ";
$result = mysqli_query($con, $query);
$response = array();

$server_name = $_SERVER['SERVER_ADDR'];

while( $row = mysqli_fetch_assoc($result) ){

    array_push($response, 
    array(
        'id'        =>$row['id'], 
        'deskripsi' =>$row['deskripsi'],
        'harga' =>$row['harga'], 
        'tgl_masuk'      =>date('d M Y', strtotime($row['tgl_masuk']))) 
    );
}

echo json_encode($response);

mysqli_close($con);

?>