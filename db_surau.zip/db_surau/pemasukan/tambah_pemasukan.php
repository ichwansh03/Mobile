<?php 

require_once('../config/koneksi_db.php');

$key = $_POST['key'];
$tgl_masuk  = $_POST['tgl_masuk'];
$harga    = $_POST['harga'];
$deskripsi      = $_POST['deskripsi'];

if ( $key == "insert" ){

    $date_format = date('Y-m-d', strtotime($tgl_masuk));

    $query = "INSERT INTO pemasukan (tgl_masuk,harga,deskripsi)
    VALUES ('$tgl_masuk','$harga','$deskripsi') ";

        if ( mysqli_query($con, $query) ){

            $result["value"] = "1";
            $result["message"] = "Success";

            echo json_encode($result);
            mysqli_close($con);
        } 
        else {
            $response["value"] = "0";
            $response["message"] = "Error! ".mysqli_error($con);
            echo json_encode($response);

            mysqli_close($con);
        }
}

?>