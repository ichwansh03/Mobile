<?php 

header("Content-Type: application/json; charset=UTF-8");

require_once('../config/koneksi_db.php');

$key = $_POST['key'];

if ( $key == "update" ){

    $id         = $_POST['id'];
    $tgl_masuk  = $_POST['tgl_keluar'];
    $harga    = $_POST['harga'];
    $deskripsi  = $_POST['deskripsi'];
    
    $date =  date('Y-m-d', strtotime($tgl_masuk));

    $query = "UPDATE pengeluaran SET 
    tgl_keluar='$tgl_masuk', 
    harga='$harga', 
    deskripsi='$deskripsi'
    WHERE id='$id' ";

        if ( mysqli_query($conn, $query) ){

                $result["value"] = "1";
                $result["message"] = "Success";
    
                echo json_encode($result);
                mysqli_close($conn);

        } 
        else {
            $response["value"] = "0";
            $response["message"] = "Error! ".mysqli_error($conn);
            echo json_encode($response);

            mysqli_close($conn);
        }
}

?>